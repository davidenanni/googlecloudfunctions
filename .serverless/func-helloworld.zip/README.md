# googlecloudfunctions
Auto-deployer functions to Google Cloud Platform
