// Package helloworld provides a set of Cloud Function samples.
package helloworld

import (
        "context"
        "cloud.google.com/go/pubsub"
        "log"
)

// PubSubMessage is the payload of a Pub/Sub event. Please refer to the docs for
// additional information regarding Pub/Sub events.
type PubSubMessage struct {
        Data []byte `json:"data"`
}

// HelloPubSub consumes a Pub/Sub message.
func HelloPubSub(ctx context.Context, m PubSubMessage) error {
        name := string(m.Data)
        if name == "" {
                name = "DEMO"
        }
        log.Printf(" %s ", name)

    client, _ := pubsub.NewClient(ctx, "tesidaviden")

    msg := "ACK"

		topic := client.Topic("response")
  		defer topic.Stop()   


  		r := topic.Publish(ctx, &pubsub.Message{
      		Data: []byte(msg),
  		})
  
  		r.Get(ctx)

        return nil
}